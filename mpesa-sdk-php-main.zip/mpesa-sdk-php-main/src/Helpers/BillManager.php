<?php 
namespace LeviZwannah\MpesaSdk\Helpers;

use LeviZwannah\MpesaSdk\Mpesa;

class BillManager extends Mpesa {

}

?>